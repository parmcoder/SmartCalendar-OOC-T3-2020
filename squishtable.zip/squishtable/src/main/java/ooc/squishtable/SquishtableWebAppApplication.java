package ooc.squishtable;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SquishtableWebAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SquishtableWebAppApplication.class, args);
	}

}
